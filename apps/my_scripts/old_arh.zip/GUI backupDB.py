import os
import shutil
from datetime import datetime
import tkinter as tk
from tkinter import messagebox, filedialog


def sanitize_filename(s):
    return "".join(c for c in s if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')


def backup_db(db_path, comment):
    if not os.path.exists(db_path):
        return False, f"Файл базы данных не найден:\n{db_path}"

    backup_folder = os.path.join(os.path.dirname(__file__), 'backup_folder')
    os.makedirs(backup_folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    base_name = f'db_backup_{timestamp}'
    backup_file = os.path.join(backup_folder, f'{base_name}.sqlite3')

    try:
        shutil.copy(db_path, backup_file)

        if comment.strip():
            log_file = os.path.join(backup_folder, f'{base_name}.txt')
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(comment.strip() + '\n')

        return True, f"✅ Копия создана:\n{backup_file}"
    except Exception as e:
        return False, f"❌ Ошибка: {e}"


# GUI-приложение
def launch_gui():
    def select_db():
        path = filedialog.askopenfilename(title="Выберите базу данных", filetypes=[("SQLite", "*.sqlite3"), ("Все файлы", "*.*")])
        if path:
            db_path_var.set(path)

    def run_backup():
        db_path = db_path_var.get().strip()
        comment = comment_entry.get("1.0", tk.END).strip()

        success, message = backup_db(db_path, comment)
        messagebox.showinfo("Результат", message)
        if success:
            comment_entry.delete("1.0", tk.END)

    # Окно
    root = tk.Tk()
    root.title("Резервное копирование БД")
    root.geometry("500x300")
    root.resizable(False, False)

    # Путь к БД
    tk.Label(root, text="Путь к базе данных:", anchor="w").pack(fill="x", padx=10, pady=(10, 0))
    db_path_var = tk.StringVar(value=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'db.sqlite3')))
    db_entry = tk.Entry(root, textvariable=db_path_var, width=50)
    db_entry.pack(padx=10, pady=5, fill="x")
    tk.Button(root, text="Выбрать файл...", command=select_db).pack(padx=10, pady=5)

    # Комментарий
    tk.Label(root, text="Комментарий к резервной копии:").pack(anchor="w", padx=10, pady=(10, 0))
    comment_entry = tk.Text(root, height=4, wrap="word")
    comment_entry.pack(padx=10, fill="both", expand=True)

    # Кнопка запуска
    tk.Button(root, text="Создать резервную копию", command=run_backup, bg="#4CAF50", fg="white", height=2).pack(pady=10)

    root.mainloop()


if __name__ == "__main__":
    launch_gui()
