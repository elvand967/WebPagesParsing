import os
import shutil
from datetime import datetime
import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter.scrolledtext import ScrolledText
import pyperclip
import subprocess
import sys

def sanitize_filename(s):
    return "".join(c for c in s if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')

def backup_db(db_path, comment, backup_folder):
    if not os.path.exists(db_path):
        return False, f"Файл базы данных не найден:\n{db_path}"

    os.makedirs(backup_folder, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    base_name = f'db_backup_{timestamp}'
    backup_file = os.path.join(backup_folder, f'{base_name}.sqlite3')

    try:
        shutil.copy(db_path, backup_file)

        if comment.strip():
            log_file = os.path.join(backup_folder, f'{base_name}.txt')
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(comment.strip() + '\n')

        return True, f"\u2705 Копия создана:\n{backup_file}"
    except Exception as e:
        return False, f'\u274C Ошибка: {e}'

def load_existing_backups(backup_folder):
    items = []
    for fname in sorted(os.listdir(backup_folder), reverse=True):
        if fname.endswith(".sqlite3"):
            base = os.path.splitext(fname)[0]
            db_path = os.path.join(backup_folder, fname)
            txt_path = os.path.join(backup_folder, base + ".txt")
            comment = ""
            if os.path.exists(txt_path):
                with open(txt_path, encoding="utf-8") as f:
                    comment = f.read().strip()
            items.append((base, db_path, txt_path if os.path.exists(txt_path) else None, comment))
    return items

def launch_gui():
    def select_db():
        path = filedialog.askopenfilename(title="Выберите базу данных", filetypes=[("SQLite", "*.sqlite3"), ("Все файлы", "*.*")])
        if path:
            db_path_var.set(path)

    def run_backup():
        db_path = db_path_var.get().strip()
        comment = comment_entry.get("1.0", tk.END).strip()

        success, message = backup_db(db_path, comment, backup_folder)
        messagebox.showinfo("Результат", message)
        if success:
            comment_entry.delete("1.0", tk.END)
            refresh_backup_list()

    def refresh_backup_list():
        backup_listbox.delete(0, tk.END)
        backup_map.clear()

        for base, db_path, txt_path, comment in load_existing_backups(backup_folder):
            display = f"{base}.sqlite3 — {comment}" if comment else f"{base}.sqlite3"
            backup_listbox.insert(tk.END, display)
            backup_map[base] = (db_path, txt_path)

    def copy_selected_path():
        selection = backup_listbox.curselection()
        if selection:
            selected = backup_listbox.get(selection[0])
            base = selected.split(" — ")[0].replace(".sqlite3", "")
            db_path, _ = backup_map.get(base, (None, None))
            if db_path:
                pyperclip.copy(db_path)
                messagebox.showinfo("Скопировано", f"Путь скопирован:\n{db_path}")
        else:
            messagebox.showwarning("Выбор", "Выберите файл из списка.")

    def delete_selected():
        selection = backup_listbox.curselection()
        if not selection:
            messagebox.showwarning("Выбор", "Выберите копию для удаления.")
            return

        selected = backup_listbox.get(selection[0])
        base = selected.split(" — ")[0].replace(".sqlite3", "")
        db_path, txt_path = backup_map.get(base, (None, None))

        if not db_path or not os.path.exists(db_path):
            messagebox.showerror("Ошибка", "Файл не найден.")
            return

        confirm = messagebox.askyesno("Удаление", f"Удалить резервную копию:\n{os.path.basename(db_path)}\nи комментарий?")
        if confirm:
            try:
                os.remove(db_path)
                if txt_path and os.path.exists(txt_path):
                    os.remove(txt_path)
                messagebox.showinfo("Удалено", "Копия и лог удалены.")
                refresh_backup_list()
            except Exception as e:
                messagebox.showerror("Ошибка", f"Ошибка при удалении: {e}")

    def open_in_explorer():
        selection = backup_listbox.curselection()
        if not selection:
            messagebox.showwarning("Выбор", "Выберите копию из списка.")
            return

        selected = backup_listbox.get(selection[0])
        base = selected.split(" — ")[0].replace(".sqlite3", "")
        db_path, _ = backup_map.get(base, (None, None))

        if db_path and os.path.exists(db_path):
            try:
                subprocess.run(['explorer', '/select,', db_path.replace('/', '\\')])
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось открыть проводник:\n{e}")
        else:
            messagebox.showerror("Ошибка", "Файл не найден.")

    def confirm_exit():
        if messagebox.askyesno("Выход", "Вы точно хотите выйти?"):
            root.destroy()
            sys.exit()

    # Окно
    root = tk.Tk()
    root.title("Резервное копирование БД")
    root.geometry("700x700")

    backup_folder = os.path.join(os.path.dirname(__file__), "backup_folder")
    os.makedirs(backup_folder, exist_ok=True)
    backup_map = {}

    tk.Label(root, text="Путь к базе данных:").pack(anchor="w", padx=10, pady=(10, 0))
    db_path_var = tk.StringVar(value=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'db.sqlite3')))
    tk.Entry(root, textvariable=db_path_var).pack(fill="x", padx=10)
    tk.Button(root, text="Выбрать файл...", command=select_db).pack(padx=10, pady=5)

    tk.Label(root, text="Комментарий к резервной копии:").pack(anchor="w", padx=10)
    comment_entry = ScrolledText(root, height=4)
    comment_entry.pack(fill="x", padx=10, pady=5)

    tk.Button(root, text="Создать резервную копию", command=run_backup, bg="#4CAF50", fg="white").pack(padx=10, pady=10)

    tk.Label(root, text="Сохранённые резервные копии:").pack(anchor="w", padx=10)
    backup_listbox = tk.Listbox(root, height=12)
    backup_listbox.pack(fill="both", expand=True, padx=10)

    btn_frame = tk.Frame(root)
    btn_frame.pack(pady=10)
    tk.Button(btn_frame, text="📋 Скопировать путь", command=copy_selected_path).pack(side="left", padx=5)
    tk.Button(btn_frame, text="📂 Открыть в проводнике", command=open_in_explorer).pack(side="left", padx=5)
    tk.Button(btn_frame, text="🗑️ Удалить копию", command=delete_selected, bg="#e53935", fg="white").pack(side="left", padx=5)
    tk.Button(btn_frame, text="🚪 Выход", command=confirm_exit).pack(side="left", padx=5)

    root.protocol("WM_DELETE_WINDOW", confirm_exit)

    refresh_backup_list()
    root.mainloop()

if __name__ == "__main__":
    try:
        import pyperclip
    except ImportError:
        print("Установите pyperclip: pip install pyperclip")
    else:
        launch_gui()
