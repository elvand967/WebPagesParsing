import os
import shutil
from datetime import datetime

def main():
    print(f"{' Резервное копирование базы данных ':^50}")
    print(f"{' Режим: работа с кодом Python ':^50}")

    # Запрос комментария
    comment = input('\nДобавьте комментарий к резервной копии (или нажмите пробел для пропуска): ').strip()
    database_backup(comment)

def sanitize_filename(s):
    # Убираем недопустимые символы для файлов Windows/*nix
    return "".join(c for c in s if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')

def database_backup(comment=""):
    path_backup_folder = os.path.join(os.path.dirname(__file__), 'backup_folder')
    if not os.path.exists(path_backup_folder):
        os.makedirs(path_backup_folder)

    db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'db.sqlite3'))
    if not os.path.exists(db_path):
        print(f"Файл базы данных не найден: {db_path}")
        return

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    sanitized_comment = f"_({sanitize_filename(comment)})" if comment else ""
    backup_filename = f'db_{timestamp}{sanitized_comment}.sqlite3'
    backup_file = os.path.join(path_backup_folder, backup_filename)

    try:
        shutil.copy(db_path, backup_file)
        print(f'✅ Создана резервная копия:\n{backup_file}')
    except Exception as e:
        print(f'❌ Ошибка при создании резервной копии: {e}')


if __name__ == "__main__":
    main()
